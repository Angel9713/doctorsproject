import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { SpecService } from '../service/spec.service';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrl: './details.component.css'
})
export class DetailsComponent {
  constructor(private bs:ActivatedRoute,private service:SpecService){}
  did:any;
  det:any;
  ngOnInit(){
    this.did=this.bs.snapshot.paramMap.get('id');
    this.det=this.service.getspecbyId(this.did);
  }

}
