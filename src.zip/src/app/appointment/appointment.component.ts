import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-appointment',
  templateUrl: './appointment.component.html',
  styleUrl: './appointment.component.css'
})
export class AppointmentComponent { 
  userdetails:any;
  // username:any;
  // phonenumber:any;
  // location:any;
  // doctors:any;
  // appointmentdate:any;
  // appointmenttime:any;
  productForm:FormGroup=new FormGroup({});
constructor(private fb:FormBuilder){
  this.productForm=this.fb.group({
    name:['',Validators.required],
    number:['',Validators.required],
    hospital:['',Validators.required],
    doctors:['',Validators.required],
    date:['',Validators.required],
    time:['',Validators.required]
  })
}
// addme(){
//   alert("Booked your Appointment");
// }
submit(){
  this.userdetails={
    name:this.productForm.value.name,
    number:this.productForm.value.number,
    hospital:this.productForm.value.hospital,
    doctors:this.productForm.value.doctors,
    date:this.productForm.value.date,
    time:this.productForm.value.time

  }
  localStorage.setItem('info',JSON.stringify(this.userdetails))
  console.log(this.userdetails)
}
}
