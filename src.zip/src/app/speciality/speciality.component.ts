import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TreatService } from '../service/treat.service';

@Component({
  selector: 'app-speciality',
  templateUrl: './speciality.component.html',
  styleUrl: './speciality.component.css'
})
export class SpecialityComponent {
  constructor(private bs:ActivatedRoute,private service:TreatService,private route:Router){}
  tid:any;
  special:any;
  ngOnInit(){
    this.tid=this.bs.snapshot.paramMap.get('id');
    this.special=this.service.gettreatbyId(this.tid);
  }
appointment(){
  this.route.navigateByUrl('/user/appoint')
}
}
