import { Component } from '@angular/core';
import { DoctorsService } from '../service/doctors.service';
import { Doctors } from '../service/doctors';

@Component({
  selector: 'app-doctors',
  templateUrl: './doctors.component.html',
  styleUrl: './doctors.component.css'
})
export class DoctorsComponent {
  doctorslist:Doctors[]=[]
  constructor(private service:DoctorsService){}
  ngOnInit(){
    this.service.getdoctors().subscribe((msg:any)=>{
      this.doctorslist=msg;
      
    })
  }


}
