import { Component } from '@angular/core';

@Component({
  selector: 'app-patient',
  templateUrl: './patient.component.html',
  styleUrl: './patient.component.css'
})
export class PatientComponent {
  constructor(){}
  name:any;
  number:any;
  hospital:any;
  doctors:any;
  date:any;
  time:any;
  user:any;
  ngOnInit(){
    this.user=localStorage.getItem('info')
    this.user=JSON.parse(this.user)
    this.name=this.user.name
    this.number=this.user.number
    this.hospital=this.user.hospital
    this.doctors=this.user.doctors
    this.date=this.user.date
    this.time=this.user.time
    console.log(this.user)
  }
  
}
