import { Injectable } from '@angular/core';
import { Schedule } from './schedule';
import { of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ScheduleService {
schedulelist:Schedule[]=[
  {
    id:1,
    name:"Angelina Jolie",
    image:"https://asgeyehospital.com//public/storage/doctors/June2023/0t5D3O0DB9nYKZMs2aMx.webp",
    title:"PHACO, FEMTO, CORNEA, REFRACTIVE (Q-LASIK, ICL & BIOPTICS) & GLAUCOMA",
    schedule:"9:00 AM - 5:00 PM"
  },
  {
    id:2,
    name:"Dr.Pramod Kumar",
    image:"https://asgeyehospital.com//public/storage/doctors/June2023/8tre6lPs5xXS1O5ZyQrh.webp",
    title:"OCULOPLASTY, OCULAR ONCOLOGY AND FACIAL AESTHETICS",
    schedule:"9:00 AM - 5:00 PM"

  },
  {
    id:3,
    name:"Lipi Mattal",
    image:"https://asgeyehospital.com//public/storage/doctors/June2023/7oWYcNBj6tmkRZZwPCFZ.webp",
    title:"PHACO, FEMTO, CORNEA & REFRACTIVE (Q-LASIK, ICL & BIOPTICS)",
    schedule:"9:00 AM - 5:00 PM"
  },
  {

      id:4,
      name:"Anna George",
      image:"https://asgeyehospital.com//public/storage/doctors/June2023/2kpoiyWuvYUBvf3kZes9.webp",
      title:"MBBS MS(Opthamology)",
      schedule:"9:00 AM - 5:00 PM"
  },
  {
    id:5,
    name:"Vikas Jain",
    image:"https://asgeyehospital.com//public/storage/doctors/June2023/NqxFGswfbJw1mHSZQfS2.webp",
    title:"PHACO, MEDICAL-RETINA, SQUINT & CORNEA",
    schedule:"9:00 AM - 5:00 PM"

  },
  {
    id:6,
    name:"Eunice Anna",
    image:"https://asgeyehospital.com//public/storage/doctors/April2024/HjefJO6iLLtSnAsY59qs.webp",
    title:"CATARACT & MEDICAL RETINA",
    schedule:"9:00 AM - 5:00 PM"
  },
  {
    id:7,
    name:"Tamar Annie",
    image:"https://asgeyehospital.com//public/storage/doctors/May2024/xiIyD6smQVozKkmA9qLB.webp",
    title:"CATARACT & MEDICAL RETINA",
    schedule:"9:00 AM - 5:00 PM"
  },
  {
    id:8,
    name:"James Nicholas",
    image:"https://asgeyehospital.com//public/storage/doctors/June2023/GNuYH2cFwC9fj5zk8Tql.webp",
    title:"CORNEA & OCULAR SURFACE,REFRACTIVE SURGERY",
    schedule:"9:00 AM - 5:00 PM"

  },
  {
    id:9,
    name:"Peter James",
    image:"https://asgeyehospital.com//public/storage/doctors/June2023/rRxsMYphdJ5O1n1CT3Im.webp",
    title:"MBBS, MS (OPHTHALMOLOGY) PHACO, CORNEA & REFRACTIVE (Q-LASIK, ICL & BIOPTICS)",
    schedule:"9:00 AM - 5:00 PM"
  }

]
  constructor() { }
  getschedule(){
    return of(this.schedulelist)
  }
}
