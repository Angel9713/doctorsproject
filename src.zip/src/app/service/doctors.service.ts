import { Injectable } from '@angular/core';
import { Doctors } from './doctors';
import { of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DoctorsService {
  doctorslist:Doctors[]=[
    {
      id:1,
      image:"https://asgeyehospital.com//public/storage/doctors/June2023/0t5D3O0DB9nYKZMs2aMx.webp",
      name:"Dr.Angelina Jolie",
      title:"PHACO, FEMTO, CORNEA, REFRACTIVE (Q-LASIK, ICL & BIOPTICS) & GLAUCOMA"

      
    },
    {
      id:2,
      image:"https://asgeyehospital.com//public/storage/doctors/June2023/8tre6lPs5xXS1O5ZyQrh.webp",
      name:"Dr.Pramod Kumar",
      title:"OCULOPLASTY, OCULAR ONCOLOGY AND FACIAL AESTHETICS"
    },
    {
      id:3,
      image:"https://asgeyehospital.com//public/storage/doctors/June2023/7oWYcNBj6tmkRZZwPCFZ.webp",
      name:"Dr.Lipi Mattal",
      title:"PHACO, FEMTO, CORNEA & REFRACTIVE (Q-LASIK, ICL & BIOPTICS)"


    },
    {
      id:4,
      image:"https://asgeyehospital.com//public/storage/doctors/June2023/2kpoiyWuvYUBvf3kZes9.webp",
      name:"Dr.Anna George",
      title:"MBBS MS(Opthamology)"
    },
    {
      
      id:5,
      image:"https://asgeyehospital.com//public/storage/doctors/June2023/NqxFGswfbJw1mHSZQfS2.webp",
      name:"Dr.Vikas Jain",
      title:"PHACO, MEDICAL-RETINA, SQUINT & CORNEA"
    },
    {
      id:6,
      image:"https://asgeyehospital.com//public/storage/doctors/April2024/HjefJO6iLLtSnAsY59qs.webp",
      name:"Dr.Eunice Anna",
      title:"CATARACT & MEDICAL RETINA"

    },
    {
      id:7,
      image:"https://asgeyehospital.com//public/storage/doctors/May2024/xiIyD6smQVozKkmA9qLB.webp",
      name:"Dr.Tamar Annie",
      title:"CORNEA & OCULAR SURFACE, CATARACT, REFRACTIVE SURGERY & OCULAR ONCOLOGY"
    },
    {
      id:8,
      image:"https://asgeyehospital.com//public/storage/doctors/June2023/GNuYH2cFwC9fj5zk8Tql.webp",
      name:"Dr.James Nicholas",
      title:"CORNEA & OCULAR SURFACE,REFRACTIVE SURGERY"
    },
    {
      id:9,
      image:"https://asgeyehospital.com//public/storage/doctors/June2023/rRxsMYphdJ5O1n1CT3Im.webp",
      name:"Dr.James peter",
      title:"MBBS, MS (OPHTHALMOLOGY) PHACO, CORNEA & REFRACTIVE (Q-LASIK, ICL & BIOPTICS)"
    }

    
  ]

  constructor() { }
  getdoctors(){
    return of(this.doctorslist)
  }
}
