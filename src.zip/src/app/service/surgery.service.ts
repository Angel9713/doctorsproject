import { Injectable } from '@angular/core';
import { spec } from './spec';

@Injectable({
  providedIn: 'root'
})
export class SurgeryService {


  constructor() { }
}
