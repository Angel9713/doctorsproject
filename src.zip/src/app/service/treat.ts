export class Treat{
    id:any;
    title:any;
    image:any;
    description:any;
}