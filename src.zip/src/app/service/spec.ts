export class spec{
    id:any;
    title:any;
    image:any;
    description:any;
    pflag:any;

}