import { Injectable } from '@angular/core';
import { Items } from './hospital';
import { of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class HospitalService {
hospitallist:Items[]=[
   
{id:1,
image:"https://asgeyehospital.com//public/storage/hospitals/July2023/ZNpahQzJir6vq9ZkekrV.webp",
title:"Pal Link Road, Jodhpur",
address:"1, Pal Link Rd, Kamla Nehru Nagar, Shyam Nagar, Jodhpur, Rajasthan 342008",
location:"https://maps.app.goo.gl/9zNiGSpsLBAimgmq6"
},
{id:2,
image:"https://asgeyehospital.com//public/storage/hospitals/August2023/NGmHmC9W8eo7OlykvVkm.webp",
title:"Paota, Jodhpur",
address:"Plot no. 7&8, Mandore Rd, Manji ka Hatha, Paota, Jodhpur, Rajasthan 342003",
location:"https://maps.app.goo.gl/UFZfkYp71cVALBVWA"
},
{id:3,
image:"https://asgeyehospital.com//public/storage/hospitals/July2023/jpheX248deb28jpoW3IJ.webp",
title:"Company Bagh, Amritsar",
address:"Plot No 3, Mukut House, Mall Rd, opp. Company Bagh, Amritsar, Punjab 143001",
location:"https://maps.app.goo.gl/rMav5MwMcperqpf4A"
},
{id:4,
image:"https://asgeyehospital.com//public/storage/hospitals/July2023/3Sj3uhwaA2S4Ss6ReDDP.webp",
title:"Sarabha Nagar, Ludhiana",
address:"Plot No.11,12-E Malhar Road, Sat Paul Mittal Rd,Sarabha Nagar, Ludhiana, Punjab 141001",
location:"https://maps.app.goo.gl/PWgoW5MtwYAKHtok9"
},
{id:5,
image:"https://asgeyehospital.com//public/storage/hospitals/July2023/JKB7KpEvUuzlbZ5bmCgD.webp",
title:"Kranti Chowk, Aurangabad",
address:"1st Floor, Plot. no. 493 /1629, Kharvel Nagar,Bhubaneswar, Odisha 751001",
location:"https://maps.app.goo.gl/c242BUa4t4woSKqs7"
},
{id:6,
image:"https://asgeyehospital.com//public/storage/hospitals/July2023/RCZv6QlaS8pdFu9rsVgS.webp",
title:"Shivaji Nagar, Bhopal",
address:"Near Khadi Emporium, opp. Khaturiya House, Rani Bazar, Bikaner, Rajasthan 334001",
location:"https://maps.app.goo.gl/fi3JoNRD4MGEVHd69"
},
{id:7,
image:"https://asgeyehospital.com//public/storage/hospitals/July2023/UNeatGKLhYM7fT5tZkCG.webp",
title:"Kharvela Nagar, Bhubaneswar",
address:"Beena Imperia Benta, Ward no :, 43, VIP Rd, Laheriasarai, Darbhanga, Bihar 846001",
location:"https://maps.app.goo.gl/3vHoFoS7TxGh9Khh6"
},
{id:8,
image:"https://asgeyehospital.com//public/storage/hospitals/July2023/OUdzKdr8zpUd7P4yreYA.webp",
title:"Rani Bazar, Bikaner",
address:"Shubham Redstone, First Floor, G.S. Road, Down Town, Bormotoria, Guwahati, Assam 781006",
location:"https://maps.app.goo.gl/LHEP8hKrB3iege846"
},
{id:9,
image:"https://asgeyehospital.com//public/storage/hospitals/July2023/0DgNrnImqwX9w1UK41Y9.webp",
title:"VIP Rd, Darbhanga",
address:"AG Prime House No. 5-5-57, Railway Station Rd, New Usmanpura, Maharashtra 431001",
location:"https://maps.app.goo.gl/m6UswvXDuXr8eqSF7"
},
]



  constructor() { }
  getlocations(){
    return of(this.hospitallist)
  }

}
