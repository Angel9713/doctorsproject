export class Items{
    id:any;
    title:any;
    image:any;
    address:any;
    location:any;
    
}