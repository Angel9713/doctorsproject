export class Doctors{
    id:any;
    image:any;
    name:any;
    title:any;
    
}