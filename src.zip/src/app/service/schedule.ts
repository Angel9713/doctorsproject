export class Schedule{
    id:any;
    name:any;
    image:any;
    title:any;
    schedule:any;
    


}