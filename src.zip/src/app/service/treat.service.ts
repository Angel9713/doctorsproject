import { Injectable } from '@angular/core';
import { Treat } from './treat';
import { of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TreatService {
  treatlist:Treat[]=[
    {id:1,
      title:"Refractive treatment",
      image:"https://asgeyehospital.com//public/storage/specialities/June2024/ZvAKRL7caryMAfJsMhFU.png",
      description:"Refractive surgery is an optional eye surgery used to improve the refractive state of the eye.Refractive surgeries are a group of surgical procedures designed to improve or correct vision by reshaping the cornea or, in some cases, by using an intraocular lens. These surgeries are typically performed to address common vision problems such as near-sightedness (myopia), farsightedness (hyperopia), and astigmatism."
     
    },
    {
      id:2,
      title:"Glaucoma treatment",
      image:"https://asgeyehospital.com//public/storage/specialities/May2023/8zrvnb2MPPzqglbWXcrz.png",
      description:" Glaucoma is a group of eye conditions that damage the optic nerve, often due to elevated introcular"      
      

    },
    {
      id:3,
      title:"Cataract treatment",
      image:"https://asgeyehospital.com//public/storage/specialities/May2023/XBxaI3AyS9krxjctQAXC.png",
      description:" Cataract surgery involves removing the clouded lens and replacing it with a clear artificial lens A cataract is an eye condition characterized by the clouding of the natural lens in the eye, leading to vision loss. Naturally, the eye's lens is clear and allows light to pass through, focusing on the retina at the back of the eye. but when a cataract develops, the lens becomes cloudy and interferes with the normal passage of light"  
    
    },
    {
      id:4,
      title:"Retinal treatment",
      image:"https://asgeyehospital.com//public/storage/specialities/June2024/3oOuqWW6zcy2GBJbIqff.png",
      description:" Cataract surgery involves removing the clouded lens and replacing it with a clear artificial lens"    
      
    },
    {
      id:5,
      title:"Neuro Opthomology",
      image:"https://asgeyehospital.com//public/storage/specialities/December2023/x0H64zAO95tXlbKKaJCC.webp",
      description:"Neuro ophthalmology is a combination of super specialty of both neurology and ophthalmology. This field deals with the complicated conditions or diseases between the brain and eyes that affect eye movement, vision, alignment, and pupillary reflexes."


    
    },
    {
      id:6,
      title:"Diabetic Retinopathy",
      image:"https://asgeyehospital.com//public/storage/specialities/May2023/vvHircbKoNGClwr4zVeT.png",
      description:"Diabetic retinopathy is an eye condition, it is caused by diabetes that occurs due to damage to the blood vessels in the retina, the light-sensitive tissue at the back of the eye. When diabetes is not well managed, it can lead to high levels of blood sugar, which in turn can cause damage to blood vessels throughout the body including those in the retina."  
      
      
    },
    {
      id:7,
      title:"Oculoplasty",
      image:"https://asgeyehospital.com//public/storage/specialities/May2023/1mXngp8iI2dlcMjCBnMc.png",
      description:"Oculoplasty, also known as oculoplastic surgery is a specialized branch of ophthalmology that focuses on the diagnosis and treatment of disorders affecting the structures around the eyes, including the eyelids, tear ducts, orbit (eye socket), and the surrounding facial tissues. The term oculoplasty is derived from the combination of oculo(related to the eye) and plasty (surgery or reconstruction)."  
    },
    {
    id:8,
      title:"LASIK surgery",
      image:"https://asgeyehospital.com//public/storage/specialities/June2024/k5p1e5De5iNKYvFh1zVv.png",
      description:"LASIK (Laser-Assisted In Situ Keratomileusis) is a popular surgical procedure that is used to correct conditions related to vision such as myopia (nearsightedness), hyperopia (farsightedness), and astigmatism. Lasik laser eye surgery aims to clear the front part of the eye, reshape the cornea, and improve how the eye focuses light onto the retina."


    },
    {
      id:9,
      title:"Contoura Lasik",
      image:"https://asgeyehospital.com//public/storage/specialities/June2024/zkCqzCmF3xVusldWn6gQ.png",
      description:"Contoura lasik is a laser vision correction technique also called topography-guided LASIK surgery. This is the most advanced type of LASIK that offers more benefits to people considering spectacle removal surgery. It eliminates the need for eyeglasses. Contoura vision surgery utilizes topography-guided technology, mapping the cornea with exceptional detail."  
    },
    {
      id:10,
      title:"ICL surgery",
      image:"https://asgeyehospital.com//public/storage/specialities/June2024/B6yxxsSJpxRJ1UxoyCLj.png",
      description:"Implantable Collamer Lens (ICL) is a type of refractive surgery, in which an artificial lens is implanted in the eyes permanently. ICL is required to treat moderate to severe Nearsightedness (Myopia), Farsightedness (Hyperopia), and Astigmatism. This surgery may be possible for people who don’t meet the criteria for LASIK surgery."  
    },
    {
      id:11,
      title:"PRK surgery",
      image:"https://asgeyehospital.com//public/storage/specialities/June2024/NLxrK6vz43laHWqXV1fH.png",
      description:"Photorefractive keratectomy is a type of laser eye surgery, that is used to treat refractive errors, Nearsightedness (myopia), Farsightedness (hyperopia), and Astigmatism) with an excimer laser (A computer-generated, cold laser beam), used to precisely remove and sculpt corneal tissue at the microscopic level). This treatment aims to reduce an individual's dependency on glasses and contact lenses."  
    },
    {
      id:11,
      title:"Squint Eye Treatment",
      image:"https://asgeyehospital.com//public/storage/specialities/June2024/FPkMyzAo7WZ4AKYgKjPg.png",
      description:"Squint eye or strabismus is one of the neurological visual disorders whereby the normal neurologic balance between the muscles controlling eye movement is disrupted, leading to misaligned eyes that cannot point at a common point simultaneously. One eye may look directly ahead as the other eye turns inward, outward, upward, or even downward. This misalignment could occur all the time or only some of the time."  
    }
    
    


  ]
  constructor() { }
  gettreat(){
    return of(this.treatlist)
  }
  gettreatbyId(id:any){
    return this.treatlist.find(Treat=>Treat.id==id)

}
}
