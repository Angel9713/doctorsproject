import { Component } from '@angular/core';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrl: './admin.component.css'
})
export class AdminComponent {
  loggedinuser:any;
  loguser:any
  name:any
ngOnInit(){
this.loguser=localStorage.getItem('admin')
this.loguser=JSON.parse(this.loguser)
this.name=this.loguser.username
}

}
