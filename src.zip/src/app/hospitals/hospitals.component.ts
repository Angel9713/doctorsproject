import { Component } from '@angular/core';
import { Items } from '../service/hospital';
import { HospitalService } from '../service/hospital.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-hospitals',
  templateUrl: './hospitals.component.html',
  styleUrl: './hospitals.component.css'
})
export class HospitalsComponent {
  hospitallist:Items[]=[]
  constructor(private service:HospitalService,private route:Router){}
  ngOnInit(){
    this.service.getlocations().subscribe((data:any)=>{
      this.hospitallist=data;
  })

  }
  navigateTo(location: string): void {
    this.route.navigate([location]);
  }
}
