import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SpecService } from '../service/spec.service';

@Component({
  selector: 'app-addspecialities',
  templateUrl: './addspecialities.component.html',
  styleUrl: './addspecialities.component.css'
})
export class AddspecialitiesComponent {
  productForm:FormGroup=new FormGroup({});
  constructor(private route:Router,private fb:FormBuilder,private service:SpecService){
    this.productForm=this.fb.group({
      id:['',Validators.required],
      title:['',Validators.required],
      price:['',Validators.required],
      description:['',Validators.required],
      category:['',Validators.required],
      image:['',Validators.required]
    })
  }
  addme(){
    console.log(this.productForm.value);
    let res=this.service.addSpecialities(this.productForm.value)
    this.route.navigateByUrl('admin/specialities');
  }
  added(){
    alert("Added Successfully");
  }

}
