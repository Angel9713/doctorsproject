import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddspecialitiesComponent } from './addspecialities.component';

describe('AddspecialitiesComponent', () => {
  let component: AddspecialitiesComponent;
  let fixture: ComponentFixture<AddspecialitiesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AddspecialitiesComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddspecialitiesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
