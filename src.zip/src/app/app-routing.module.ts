import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { AdminComponent } from './admin/admin.component';
import { HomeComponent } from './home/home.component';
import { UserComponent } from './user/user.component';
import { TreatmentsComponent } from './treatments/treatments.component';
import { DoctorsComponent } from './doctors/doctors.component';
import { AppointmentComponent } from './appointment/appointment.component';
import { SpecialityComponent } from './speciality/speciality.component';
import { HospitalsComponent } from './hospitals/hospitals.component';
import { ProfileComponent } from './profile/profile.component';
import { SpecialitiesComponent } from './specialities/specialities.component';
import { AddspecialitiesComponent } from './addspecialities/addspecialities.component';
import { ManagespecialitiesComponent } from './managespecialities/managespecialities.component';
import { DetailsComponent } from './details/details.component';
import { PatientComponent } from './patient/patient.component';
import { ViewscheduleComponent } from './viewschedule/viewschedule.component';

const routes: Routes = [
  {path:'',component:LoginComponent},
  {path:'user',component:UserComponent,
    children:[
      {path:'home',component:HomeComponent},
      {path:'treat',component:TreatmentsComponent},
      {path:'appoint',component:AppointmentComponent},
      {path:'doctors',component:DoctorsComponent},
      {path:'specials/:id',component:SpecialityComponent},
      {path:'hospital',component:HospitalsComponent}
    ]
  },
  {path:'admin',component:AdminComponent,
    children:[
      {path:'profile',component:ProfileComponent},
      {path:'spec',component:SpecialitiesComponent},
      {path:'add',component:AddspecialitiesComponent},
      {path:'manage',component:ManagespecialitiesComponent},
      {path:'det/:id',component:DetailsComponent},
      {path:'patient',component:PatientComponent},
      {path:'view',component:ViewscheduleComponent}
    ]
  
 
 
  }
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
