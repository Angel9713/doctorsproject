import { Component } from '@angular/core';
import { Schedule } from '../service/schedule';
import { ScheduleService } from '../service/schedule.service';

@Component({
  selector: 'app-viewschedule',
  templateUrl: './viewschedule.component.html',
  styleUrl: './viewschedule.component.css'
})
export class ViewscheduleComponent {
  schedulelist:Schedule[]=[]
  constructor(private service:ScheduleService){}
  ngOnInit(){
    this.service.getschedule().subscribe((data:any)=>{
      this.schedulelist=data
    })

  }

}
