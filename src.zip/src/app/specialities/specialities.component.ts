import { Component } from '@angular/core';
import { spec } from '../service/spec';
import { SpecService } from '../service/spec.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-specialities',
  templateUrl: './specialities.component.html',
  styleUrl: './specialities.component.css'
})
export class SpecialitiesComponent {
  speclist:spec[]=[]
  constructor(private service:SpecService,private route:Router){}
  ngOnInit(){
    this.service.getspec().subscribe((data:any)=>{
      this.speclist=data;
    
    })
  }
  det(sid:any){
    this.route.navigateByUrl('/admin/det/'+sid)

  }


}
