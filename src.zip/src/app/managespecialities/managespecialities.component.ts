import { Component } from '@angular/core';
import { spec } from '../service/spec';
import { SpecService } from '../service/spec.service';

@Component({
  selector: 'app-managespecialities',
  templateUrl: './managespecialities.component.html',
  styleUrl: './managespecialities.component.css'
})
export class ManagespecialitiesComponent {
  speclist:spec[]=[]
  constructor(private service:SpecService){}
  deleteme(sid:any){
    let res=this.service.deleteProducts(sid);
    alert(res);
  }
  editcontent(s:any){
    s.pflag=true;
  }
  updateme(s:any){
    s.pflag=false;
    let res=this.service.updateProducts(s);
  }
  ngOnInit(){
    this.service.getspec().subscribe((data)=>{
      this.speclist=data;
    })
  }

}
