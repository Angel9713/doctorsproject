import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManagespecialitiesComponent } from './managespecialities.component';

describe('ManagespecialitiesComponent', () => {
  let component: ManagespecialitiesComponent;
  let fixture: ComponentFixture<ManagespecialitiesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ManagespecialitiesComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ManagespecialitiesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
