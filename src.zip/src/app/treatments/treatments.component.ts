import { Component } from '@angular/core';
import { Treat } from '../service/treat';
import { TreatService } from '../service/treat.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-treatments',
  templateUrl: './treatments.component.html',
  styleUrl: './treatments.component.css'
})
export class TreatmentsComponent {
  treatlist:Treat[]=[]
  constructor(private service:TreatService,private route:Router){}
  ngOnInit(){
    this.service.gettreat().subscribe((data:any)=>{
      this.treatlist=data
    })
  }
  specials(tid:any){
    this.route.navigateByUrl('/user/specials/'+tid)

  }


 
    
}
